var bcrypt = require('bcryptjs');

/*Synchronous Approach */
var hash = bcrypt.hashSync("Karthik",bcrypt.genSaltSync(10));
console.log("Generated Hash for 'Karthik' Synchronously: " + hash);
console.log("Comparing 'Karthik' with generated hash : "+bcrypt.compareSync("Karthik", hash)); // true
console.log("Comparing 'karthik' with generated hash : "+bcrypt.compareSync("karthik", hash)); // true



/*Asynchronous Approach*/
bcrypt.hash("Karthik", bcrypt.genSaltSync(10), function(err, hash) {
	console.log("Generated Hash for 'Karthik' Asynchronously: " + hash);
	bcrypt.compare("Karthik", hash, function(err, res) {
		console.log("Comparing 'Karthik' with generated hash : "+res); // true
	});
});
