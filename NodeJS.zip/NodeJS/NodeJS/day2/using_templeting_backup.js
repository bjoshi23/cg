
var express = require("express");
var app=express();

app.set("view engine",'ejs');
app.set("views","./views");

app.use(express.static('public'));

app.get("/hello/:name", function(req,res)
{
  var namereceived = req.params.name;
  res.render('first_view',{name:namereceived});
});
app.listen(3000);
