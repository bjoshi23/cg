/* Middleware are functions that have access to request and
response objects and next function middleware function.
It is used to modify request and response objects for tasks 
like parsing request bodies, parsing cookies, adding response headers 

*/
      var express = require("express");
      app = express(); 

      app.use(function (req, res, next) {
          console.log (" A new request receive at " + Date.now());
          req.name="Anil";
          next();
      });
      
      app.get("/hello", function(req,res)
      {
          res.send("<h1> Hello How are you"+req.name+" <h1>");
      });
      
     
      app.listen(3000);
