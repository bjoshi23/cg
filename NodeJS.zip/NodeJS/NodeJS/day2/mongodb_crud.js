
//connecting to mongodb server

var mongoclient= require("mongodb").MongoClient;
var url = "mongodb://localhost:27017/mydb";


mongoclient.connect(url,function(err,db)
{
  if (err) console.log(err)
  else {
  console.log ("Connected to Database");
  var myemp= {"name":"Har","dept":"training", "location":"mumbai"};
  //db.collection("employee").insertOne(myemp);
  // find 
  db.collection("employee").find({"name":"Har"}).toArray(function (err,result)
    {
        console.log(result);
    });
  // remove
  db.collection("employee").remove({"name":"Har"},function (err,result)
    {
        console.log("number of records deleted " +result);
    });

    //update record
   
   db.collection("employee").update({"name":"anil"}, {"salary":6000}, function (err, result)
   {
      console.log("record updated"); 
   })

    
  db.close();
  }
});

