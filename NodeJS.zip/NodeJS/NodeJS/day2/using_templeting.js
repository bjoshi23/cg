
var express = require("express");
var app=express();

app.set("view engine",'ejs');
app.set("views","./views");
app.use(express.static('public'));
var bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

app.get("/sayhello", function(req,res)
{
    res.render('form');
});

app.post("/handleRequest", function(req,res)
{
    console.log(req.body);
    res.render("response.ejs",req.body);
});

app.listen(3000);
