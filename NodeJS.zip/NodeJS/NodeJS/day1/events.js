var events = require('events');


var eventEmitter = new events.EventEmitter(); //obtain the event object
var myCallback = function(data) {    //this callback event handler receving data
     console.log('Got data: '+data);
};

var otherCallback = function(data) {    //this callback event handler receving data
     console.log('Got data other call back: '+data);
};

eventEmitter.on("myEvent",myCallback);  //assign event handler with event name
eventEmitter.on("myEvent",otherCallback);

var fireEvent = function () 
{
    eventEmitter.emit("myEvent","Anil"); //fire the event
}

fireEvent();

eventEmitter.removeListener("myEvent",myCallback);

fireEvent();




