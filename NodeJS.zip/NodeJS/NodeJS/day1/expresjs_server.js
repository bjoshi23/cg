var express = require("express");
var app= express();

var handleRequest = function( req, res)
{
    res.send("<h1>Hello </h1>")
}

app.get("/hello", handleRequest);

app.get("/about", function( req, res)
{
    res.send("<h1>Hello- This is for  about request  </h1>")
}
);

app.listen(8080); 