//process information 

/* provides 
pid, args, platform, env,version ..
*/

console.log(process.id);