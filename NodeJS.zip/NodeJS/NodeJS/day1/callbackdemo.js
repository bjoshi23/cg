
var result = function(v)
{
    console.log ("result="+v);
}


var add = function(a,b,resultfn){

 var c = a+b;
 resultfn(c);

}

add(3,5,result);