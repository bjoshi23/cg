exports.myDateTime= function() {
   //aditional functionalities 
   return Date();    
}

 


