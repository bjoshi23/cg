var dt=require('./myfirstmodule');

console.log ("Hello World");
console.log(" The date and time currently :" +dt.myDateTime())