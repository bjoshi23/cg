var ejs= require('ejs');
var fs= require('fs');

fs.readFile("./test.ejs",'utf-8', function(err,data){
    if(err) {
        console.log(err);
    } else 
    {
        var templateoutput=ejs.compile(data);
        var htmlcode=templateoutput({"title":" L and D", "name": "Anil"});
        console.log(htmlcode);
    }
})