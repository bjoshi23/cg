var http = require('http');
var fs = require("fs");
var url= require ("url");
//create server
http.createServer( function (request,response){
var pathname = url.parse(request.url).pathname;
//file requested
console.log( " Requested: "+ pathname);
fs.readFile(pathname.substr(1),function(err, data)
{
    if (err) {
        console.log(err);
        response.writeHead(404,{'Content_Type':'text/html'});
    } else
    {
       response.writeHead(200,{'Content_Type':'text/html'}); 
       response.write(data.toString()) ;
    }
    response.end();
});
}
).listen(8080);