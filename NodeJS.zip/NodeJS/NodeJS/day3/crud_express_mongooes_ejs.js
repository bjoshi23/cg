var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));


var mongoose = require('mongoose');
var url = "mongodb://localhost:27017/mydb";


mongoose.connect(url, function(err,result){
   if(err) 
      console.log("Error in connection" + err);
   else
      console.log("Connection succesful");
}
);


var EmployeeSchema = new mongoose.Schema({
  name: String,
  address: String,
  position: String,
  salary: Number,
  updated_at: { type: Date, default: Date.now },
});

var Employee=mongoose.model("empmgmt",EmployeeSchema);;

/* GET home page. */
app.get('/start', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

app.get('/employees', function(req, res, next) {
    //connect
    Employee.find({}).exec(function (err, employees) {
    if (err) {
      console.log("Error:", err);
    }
    else {
        console.log(employees);
       res.render('./employees/index', {employees:employees});
    }
  });
 
});

app.get('/employees/create', function(req, res, next) {

  res.render('./employees/create', {});

});

app.post("/employees/save", function(req, res, next) {
  console.log(req.body);

  var employee = new Employee(req.body);

  employee.save(function(err) {
    if(err) {
      console.log(err);
      res.render("/employees/create");
    } else {
      console.log("Successfully created an employee.");
     // res.redirect("/employees/show/"+employee._id);
     res.redirect("/employees");
    }
  });
   
});


app.get('/employees/show/:id', function(req, res, next) {

Employee.findOne({_id: req.params.id}).exec(function (err, employee) {
    if (err) {
      console.log("Error:", err);
    }
    else {
      res.render("./employees/edit", {employee: employee});
    }
  });

});


app.post("/employees/update/:id", function(req, res, next) {
  Employee.findByIdAndUpdate(req.params.id, { $set: { name: req.body.name, address: req.body.address, position: req.body.position, salary: req.body.salary }}, { new: true }, function (err, employee) {
    if (err) {
      console.log(err);
      res.render("../views/employees/edit", {employee: req.body});
    }
    res.redirect("/employees/show/"+employee._id);
  });
   
});


app.post("/employees/delete/:id", function(req, res, next) {
  Employee.remove({_id: req.params.id}, function(err) {
    if(err) {
      console.log(err);
    }
    else {
      console.log("Employee deleted!");
      res.redirect("/employees");
    }
  });
   
});

app.listen(3000);






